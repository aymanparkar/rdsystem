<div class="card-body text-center p-4 install-progress">
    <div class="mt-4">
        <i
            class="spinner-border spinner-border-lg text-muted"
            style="width: 3rem; height: 3rem;border-width: .4em;"
            role="status"
        ></i>
    </div>
    <h3 class="my-4">Setting up your application...&nbsp;&nbsp;&#127858;</h3>
    <p class="message"></p>
</div>
